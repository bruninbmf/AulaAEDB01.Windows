﻿using AulaAEDB01.Windows.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AulaAEDB01.Windows.Helper
{
    public static class DataHelper
    {
            public static List<Genero> ListaGenero {  get; set; }
            
    }
    public static class DataHekper1
    {
        public static List<Autor> ListaAutor { get; set; }
    }
}
